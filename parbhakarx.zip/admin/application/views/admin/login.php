<?php
$no_visible_elements = true;
$this->load->view('admin/header-login'); ?>

    <div class="row">
        <div class="col-md-12 center login-header">
            <h2>Welcome to </h2>
        </div>
        <!--/span-->
    </div><!--/row-->

    <div class="row">
        <div class="well col-md-4 center login-box">
		<?php if(@$error_message || form_error('adminUsername') || form_error('adminPassword')) {?>
            <div class="alert alert-danger">
                <?php echo @$error_message; ?>
				<?php echo form_error('adminUsername'); ?>
				<?php echo form_error('adminPassword'); ?>
            </div>
		<?php } ?>	
            <form class="form-horizontal" action="<?php echo base_url('admin/login.html');?>" method="post">
                <fieldset>
                    <div class="input-group input-group-lg">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user red"></i></span>
                        <input name="adminUsername" type="text" class="form-control" placeholder="Username" value="<?php echo set_value("adminUsername"); ?>">
                    </div>
                    <div class="clearfix"></div><br>

                    <div class="input-group input-group-lg">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock red"></i></span>
                        <input name="adminPassword" type="password" class="form-control" placeholder="Password">
                    </div>
                    <div class="clearfix"></div>
 
                    <p class="center col-md-5">
                        <button name="adminLoginSubmit" type="submit" class="btn btn-primary">Login</button>
                    </p>
                </fieldset>
            </form>
        </div>
        <!--/span-->
    </div><!--/row-->
<?php $this->load->view('admin/footer');  ?>