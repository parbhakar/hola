<?php $this->load->view('admin/header');?>
    <div>
        <ul class="breadcrumb">
            <li>
                <a href="<?php echo base_url('Admin'); ?>">Home</a>
            </li>
            <li>
                <a href="javascript:;">Inquiry List</a>
            </li>
        </ul>
    </div>

    <div class="row">
	<div><?php echo @$this->session->userdata('message');$this->session->unset_userdata('message') ?></div>
    <div class="box col-md-12">
    <div class="box-inner">
    <div class="box-header well" data-original-title="">
        <h2><i class="glyphicon glyphicon-user"></i> Inquiry List</h2>

        <div class="box-icon">
            <a href="javascript:;" class="btn btn-minimize btn-round btn-default"><i class="glyphicon glyphicon-chevron-up"></i></a>
             
        </div>
    </div>
    <div class="box-content">
   
    <table class="table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
    <tr>
        <th>S.No</th>
        <th>Form Name</th>
        <th>Inquiry For Date & Time</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Inquiry Purpose</th>
        <th>Language</th>
        <th>Message</th>
        <th>Created</th>
        <th>Status</th>
        <th>Action</th> 
        
    </tr>
    </thead>
    <tbody>
	<?php
	 $kk=1;
	if(count($inquirylists)>0)
	{
		foreach($inquirylists as $ae) {
	?>
    <tr>
        <td><?php echo $kk; ?></td>
        <td><?php echo $ae->form_name; ?></td>
        <td><?php echo date('d, M Y H:i',strtotime($ae->inquiry_date_time)); ?></td>
        <td><?php echo $ae->name; ?></td>
        <td><?php echo $ae->email; ?></td>
        <td><?php echo $ae->phone; ?></td>
        <td><?php echo $ae->inquiry_purpose; ?></td>
        <td><?php echo $ae->language; ?></td>
        <td><?php echo $ae->message; ?></td>
        <td><?php echo date('d, M Y H:i',strtotime($ae->created)); ?></td>

        <td><?php $status=$ae->status;
        if ($status == 1) {
            echo "Pending";
        }elseif ($status == 2) {
            echo "Not Accept";
        }elseif ($status == 3) {
            echo "Accept";
        }elseif ($status == 4) {
            echo "Reject";
        }?></td>
       
       <td><a href="<?php echo base_url();?>Admin/assign/<?php echo $ae->id; ?>" class="btn btn-primary btn-xs">Assign</a></td>
    </tr>
	<?php $kk++; } } ?>
    </tbody>
    </table>
    </div>
    </div>
    </div>
    <!--/span-->

    </div><!--/row-->
<script>
function ConfirmPackDelete()
{
	var confDel = confirm("Do You Really want to Delete this Package ?");
	
	if(confDel==1) { return true; } else { return false; }
	 
}
</script>
<?php $this->load->view('admin/footer');?>