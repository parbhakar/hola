<?php if (!isset($no_visible_elements) || !$no_visible_elements) { ?>
    <!-- content ends -->
    </div><!--/#content.col-md-0-->
<?php } ?>
</div><!--/fluid-row-->
<?php if (!isset($no_visible_elements) || !$no_visible_elements) { ?>

  

<?php } ?>
    <footer class="row">
        <p class="col-md-12 col-sm-12 col-xs-12 copyright"> Site Credits </p>
    </footer>

</div><!--/.fluid-container-->
<script type="text/javascript">
    $(document).ready(function() {
        $('select[name="plan_brand_id"]').on('change', function() {
            //alert('Check Value');
            var brand_id = $(this).val();
            if(brand_id) {
                //alert('Check Value');
                $.ajax({
                    url: '<?php echo base_url(); ?>Admin/getModelForPlans/'+brand_id,
                    type: "POST",
                    dataType: "json",
                    success:function(data) {
                        $('select[name="plan_model_id"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="plan_model_id"]').append('<option value="'+ value.model_id +'">'+ value.model_title +'</option>');
                        });
                    }
                });
            }else{
                $('select[name="plan_model_id"]').empty();
            }
        });
    });
</script>
<!-- external javascript -->

<script src="<?php echo base_url('ui');?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="<?php echo base_url('ui');?>/js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='<?php echo base_url('ui');?>/bower_components/moment/min/moment.min.js'></script>
<script src='<?php echo base_url('ui');?>/bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='<?php echo base_url('ui');?>/js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="<?php echo base_url('ui');?>/bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="<?php echo base_url('ui');?>/bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="<?php echo base_url('ui');?>/js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="<?php echo base_url('ui');?>/bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<script src="<?php echo base_url('ui');?>/bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
<!-- star rating plugin -->
<script src="<?php echo base_url('ui');?>/js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="<?php echo base_url('ui');?>/js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="<?php echo base_url('ui');?>/js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="<?php echo base_url('ui');?>/js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="<?php echo base_url('ui');?>/js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="<?php echo base_url('ui');?>/js/charisma.js"></script>

</body>
</html>
