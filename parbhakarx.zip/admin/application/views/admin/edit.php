<?php $this->load->view('admin/header');?>
<div>
    <ul class="breadcrumb">
        <li>
            <a href="<?php echo base_url('Admin'); ?>">Home</a>
        </li>
        <li>
            <a href="<?php echo base_url('Admin'); ?>">Dashboard</a>
        </li>
    </ul>
</div>

<div class="box-content">
  <div class="row">
      <div class="col-md-12">
           <form action="<?php echo base_url(); ?>Admin/submiteditform" method="post" >
               
               <input type="hidden" name="id" value="<?php echo $leads->id; ?>">
                        <!--<div class="col-md-6">-->
                        <!--    <div class="form-group">-->
                        <!--        <label for="exampleInputEmail1">Enter Facilitys</label>-->
                        <!--        <input type="text" name="services" id="services" maxlength="30"  class="form-control" placeholder="Enter Facilitys" value="<?php echo @$leads->services; ?>">-->
                        <!--     </div>-->
                        <!--    <?php echo form_error( "services"); ?>-->
                        <!--</div>-->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Full Name</label>
                                <input type="text" name="name" id="name" maxlength="30"  class="form-control" placeholder="Enter full name" value="<?php echo $leads->name; ?>">
                                                        </div>
                                                        <?php echo form_error("name"); ?>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Mobile No</label>
                                <input type="number" name="phone" id="mobile" maxlength="10" class="form-control"  placeholder="Enter mobile no." value="<?php echo $leads->phone; ?>">
                                                        </div>
                                                        <?php echo form_error("phone"); ?>
                        </div>
                         <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input type="email" name="email" id="email" maxlength="40" class="form-control"  placeholder="Enter email id" value="<?php echo $leads->email; ?>">
                                                        </div>
                                                        <?php echo form_error("email"); ?>
                        </div>
                        <?php /* <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Select state</label>
                               <select name="state" id="state"  class="form-control">
                                                        <option value="">Select state</option>
                                                        <option value="Andhra Pradesh" <?php if($leads->state =="Andhra Pradesh"){ echo "selected"; }else{ } ?>>Andhra Pradesh</option>
                                                        <option value="Andaman and Nicobar Islands" <?php if($leads->state =="Andaman and Nicobar Islands"){ echo "selected"; }else{ } ?>>Andaman and Nicobar Islands</option>
                                                        <option value="Arunachal Pradesh" <?php if($leads->state =="Arunachal Pradesh"){ echo "selected"; }else{ } ?>>Arunachal Pradesh</option>
                                                        <option value="Assam" <?php if($leads->state =="Assam"){ echo "selected"; }else{ } ?>>Assam</option>
                                                        <option value="Bihar" <?php if($leads->state =="Bihar"){ echo "selected"; }else{ } ?>>Bihar</option>
                                                        <option value="Chandigarh" <?php if($leads->state =="Chandigarh"){ echo "selected"; }else{ } ?>>Chandigarh</option>
                                                        <option value="Chhatisgarh" <?php if($leads->state =="Chhatisgarh"){ echo "selected"; }else{ } ?>>Chhatisgarh</option>
                                                        <option value="Dadra and Nagar Haveli" <?php if($leads->state =="Dadra and Nagar Haveli"){ echo "selected"; }else{ } ?>>Dadra and Nagar Haveli</option>
                                                        <option value="Daman and Diu" <?php if($leads->state =="Daman and Diu"){ echo "selected"; }else{ } ?>>Daman and Diu</option>
                                                        <option value="Delhi NCR" <?php if($leads->state =="Delhi NCR"){ echo "selected"; }else{ } ?>>Delhi NCR</option>
                                                        <option value="Goa" <?php if($leads->state =="Goa"){ echo "selected"; }else{ } ?>>Goa</option>
                                                        <option value="Gujarat" <?php if($leads->state =="Gujarat"){ echo "selected"; }else{ } ?>>Gujarat</option>
                                                        <option value="Haryana" <?php if($leads->state =="Haryana"){ echo "selected"; }else{ } ?>>Haryana</option>
                                                        <option value="Himachal Pradesh" <?php if($leads->state =="Himachal Pradesh"){ echo "selected"; }else{ } ?>>Himachal Pradesh</option>
                                                        <option value="Jammu &amp; Kashmir" <?php if($leads->state =="Jammu & Kashmir"){ echo "selected"; }else{ } ?>>Jammu &amp; Kashmir</option>
                                                        <option value="Jharkhand" <?php if($leads->state =="Jharkhand"){ echo "selected"; }else{ } ?>>Jharkhand</option>
                                                        <option value="Karnataka" <?php if($leads->state =="Karnataka"){ echo "selected"; }else{ } ?>>Karnataka</option>
                                                        <option value="Kerala" <?php if($leads->state =="Kerala"){ echo "selected"; }else{ } ?>>Kerala</option>
                                                        <option value="Lakshadweep" <?php if($leads->state =="Lakshadweep"){ echo "selected"; }else{ } ?>>Lakshadweep</option>
                                                        <option value="Madhya Pradesh" <?php if($leads->state =="Madhya Pradesh"){ echo "selected"; }else{ } ?>>Madhya Pradesh</option>
                                                        <option value="Maharashtra" <?php if($leads->state =="Maharashtra"){ echo "selected"; }else{ } ?>>Maharashtra</option>
                                                        <option value="Manipur" <?php if($leads->state =="Manipur"){ echo "selected"; }else{ } ?>>Manipur</option>
                                                        <option value="Mizoram" <?php if($leads->state =="Mizoram"){ echo "selected"; }else{ } ?>>Mizoram</option>
                                                        <option value="Nagaland" <?php if($leads->state =="Nagaland"){ echo "selected"; }else{ } ?>>Nagaland</option>
                                                        <option value="Odisha" <?php if($leads->state =="Odisha"){ echo "selected"; }else{ } ?>>Odisha</option>
                                                        <option value="Puducherry" <?php if($leads->state =="Puducherry"){ echo "selected"; }else{ } ?>>Puducherry</option>
                                                        <option value="Punjab" <?php if($leads->state =="Punjab"){ echo "selected"; }else{ } ?>>Punjab</option>
                                                        <option value="Rajasthan" <?php if($leads->state =="Rajasthan"){ echo "selected"; }else{ } ?>>Rajasthan</option>
                                                        <option value="Sikkim" <?php if($leads->state =="Sikkim"){ echo "selected"; }else{ } ?>>Sikkim</option>
                                                        <option value="Tamilnadu" <?php if($leads->state =="Tamilnadu"){ echo "selected"; }else{ } ?>>Tamilnadu</option>
                                                        <option value="Telangana" <?php if($leads->state =="Telangana"){ echo "selected"; }else{ } ?>>Telangana</option>
                                                        <option value="Tripura" <?php if($leads->state =="Tripura"){ echo "selected"; }else{ } ?>>Tripura</option>
                                                        <option value="Uttar Pradesh East" <?php if($leads->state =="Uttar Pradesh East"){ echo "selected"; }else{ } ?>>Uttar Pradesh East</option>
                                                        <option value="Uttar Pradesh West" <?php if($leads->state =="Uttar Pradesh West"){ echo "selected"; }else{ } ?>>Uttar Pradesh West</option>
                                                        <option value="Uttarakhand" <?php if($leads->state =="Uttarakhand"){ echo "selected"; }else{ } ?>>Uttarakhand</option>
                                                        <option value="West Bengal" <?php if($leads->state =="West Bengal"){ echo "selected"; }else{ } ?>>West Bengal</option>
                                                    </select>
                                                        </div>
                                                        <?php echo form_error("state"); ?>
                        </div>
                         <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">City</label>
                                <input type="text"  name="city" id="city" maxlength="30" placeholder="Enter city name" class="form-control" value="<?php echo $leads->city; ?>">
                                                        </div>
                                                        <?php echo form_error("city"); ?>
                        </div> */?>
                         <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">How did you hear about us</label>
                                <select name="source" value="" class="form-control">
                                    <option value="">How did you hear about us </option>
                                    <option value="Email" <?php if($leads->source =="Email"){ echo "selected"; }else{ } ?>>Email</option>
                                    <option value="Web Banner" <?php if($leads->source =="Web Banner"){ echo "selected"; }else{ } ?>>Web Banner</option>
                                    <option value="Facebook" <?php if($leads->source =="Facebook"){ echo "selected"; }else{ } ?>>Facebook</option>
                                    <option value="Twitter" <?php if($leads->source =="Twitter"){ echo "selected"; }else{ } ?>>Twitter</option>
                                    <option value="LinkedIn" <?php if($leads->source =="LinkedIn"){ echo "selected"; }else{ } ?>>LinkedIn</option>
                                    <option value="Google Search" <?php if($leads->source =="Google Search"){ echo "selected"; }else{ } ?>>Google Search</option>
                                    <option value="Reference" <?php if($leads->source =="Reference"){ echo "selected"; }else{ } ?>>Reference</option>
                                    <option value="Others" <?php if($leads->source =="Others"){ echo "selected"; }else{ } ?>>Others</option>
                                </select>
                                                        </div>
                                                        <?php echo form_error("source"); ?>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Message</label>
                                 <textarea name="messages" id="message" maxlength="255" placeholder="Enter message" class="form-control"><?php echo $leads->message; ?></textarea>
                                                        </div>
                                                        <?php echo form_error("message"); ?>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Remark</label>
                                 <textarea name="remark" id="remark" maxlength="255" placeholder="Enter Remark" class="form-control"><?php echo $leads->remark; ?></textarea>
                                                        </div>
                                                        <?php echo form_error("remark"); ?>
                        </div>
                        <div class="col-xs-12">
                            <div class="web-form">
                                <button type="submit" id="submit" name="submit" class="btn-submit">Submit</button>
                                <button type="reset" id="reset" onclick="resetFunction()" name="reset" class="btn-reset">Reset</button>
                            </div>
                        </div>
                    </form>
      </div>
  </div>
    </div>


<?php $this->load->view('admin/footer');?>