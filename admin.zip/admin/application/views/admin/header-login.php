<?php $this->load->view('admin/config');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Enquery Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Exproin">
    <meta name="author" content="Exproin">

    <!-- The styles -->
    <link href="<?php echo base_url('ui');?>/css/bootstrap-cerulean.min.css" rel="stylesheet">

    <link href="<?php echo base_url('ui');?>/css/charisma-app.css" rel="stylesheet">
    <link href='<?php echo base_url('ui');?>/bower_components/fullcalendar/dist/fullcalendar.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/bower_components/fullcalendar/dist/fullcalendar.print.css' rel='stylesheet' media='print'>
    <link href='<?php echo base_url('ui');?>/bower_components/chosen/chosen.min.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/bower_components/colorbox/example3/colorbox.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/jquery.noty.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/noty_theme_default.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/elfinder.min.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/elfinder.theme.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/uploadify.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/animate.min.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="<?php echo base_url('ui');?>/bower_components/jquery/jquery.min.js"></script>

    <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- The fav icon -->
    <!-- <link rel="shortcut icon" href="<?php echo base_url('ui');?>/img/favicon.ico"> -->
<script>
function ConfirmDelete()
{
  var x = confirm("Are you sure you want to delete ?");
  if (x)
      return true;
  else
    return false;
}
</script>
</head>

<body>
<?php if (!isset($no_visible_elements) || !$no_visible_elements) { ?>
    <!-- topbar starts -->
    <div class="navbar navbar-default" role="navigation"  >

        <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
             <img alt="Enquery" src="https://www.Enquery.in/images/Enquery/logo.png" class="hidden-xs" style="height:50px;     margin-left: 20px;"/>

        </div>
    </div>
    <!-- topbar ends -->
<?php } ?>
<div class="ch-container">
    <div class="row">
        <?php if (!isset($no_visible_elements) || !$no_visible_elements) { ?>


       
        <div id="content" class="col-lg-12 col-sm-12">
            <!-- content starts -->
            <?php } ?>
