<?php $this->load->view('admin/config');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Enquery Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Exproin">
    <meta name="author" content="Exproin">

    <!-- The styles -->
    <link href="<?php echo base_url('ui');?>/css/bootstrap-cerulean.min.css" rel="stylesheet">

    <link href="<?php echo base_url('ui');?>/css/charisma-app.css" rel="stylesheet">
    <link href='<?php echo base_url('ui');?>/bower_components/fullcalendar/dist/fullcalendar.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/bower_components/fullcalendar/dist/fullcalendar.print.css' rel='stylesheet' media='print'>
    <link href='<?php echo base_url('ui');?>/bower_components/chosen/chosen.min.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/bower_components/colorbox/example3/colorbox.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/jquery.noty.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/noty_theme_default.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/elfinder.min.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/elfinder.theme.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/uploadify.css' rel='stylesheet'>
    <link href='<?php echo base_url('ui');?>/css/animate.min.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="<?php echo base_url('ui');?>/bower_components/jquery/jquery.min.js"></script>

    <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- The fav icon -->
    <!-- <link rel="shortcut icon" href="<?php echo base_url('ui');?>/img/favicon.ico"> -->
<!-- Date Picker Script Start -->

<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  <script>
  $(document).ready(function() {
    $("#datepicker").datepicker();
    $("#datepicker2").datepicker();
  });
  </script>
<style type="text/css">
    table#DataTables_Table_0 {
        font-size: 12px;
    }
</style>
<!-- Date Picker Script End -->
</head>

<body>
<?php if (!isset($no_visible_elements) || !$no_visible_elements) { ?>
    <!-- topbar starts -->
    <div class="navbar navbar-default" role="navigation">

        <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
     <img alt="Enquery" src="https://www.Enquery.in/images/Enquery/logo.png" class="hidden-xs" style="height:50px;     margin-left: 20px;"/>


            <!-- user dropdown starts -->
            <div class="btn-group pull-right">
                <button class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                    <i class="glyphicon glyphicon-user"></i><span class="hidden-sm hidden-xs"> admin</span>
                    <span class="caret"></span>
                </button>
                <ul class="dropdown-menu">
                   <?php 
					/* 
						<li><a href="#">Profile</a></li>
						<li class="divider"></li>
					*/
					?>
                    <li><a href="<?php echo base_url('Admin/logout.html'); ?>">Logout</a></li>
                </ul>
            </div>
            <!-- user dropdown ends -->

            <!-- theme selector starts -->
 
            <!-- theme selector ends -->

 

        </div>
    </div>
    <!-- topbar ends -->
<?php } ?>
<div class="ch-container">
    <div class="row">
        <?php if (!isset($no_visible_elements) || !$no_visible_elements) { ?>

        <!-- left menu starts -->
        <div class="col-sm-2 col-lg-2">
            <div class="sidebar-nav">
                <div class="nav-canvas">
                    <div class="nav-sm nav nav-stacked">
                    </div>
                    <ul class="nav nav-pills nav-stacked main-menu">
                        <li class="nav-header">Main</li>
                        <li><a class="ajax-link" href="<?php echo base_url('admin/dashboard.html'); ?>"><i class="glyphicon glyphicon-home"></i><span> Dashboard</span></a></li>
                        
                        
                    </ul>
					<span style="display:none;">
                    <label id="for-is-ajax" for="is-ajax"><input id="is-ajax" type="checkbox" > Ajax on menu</label>
					</span>
                </div>
            </div>
        </div>
        <!--/span-->
        <!-- left menu ends -->

        

        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <?php } ?>
