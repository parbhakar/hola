<?php $this->load->view('admin/header');?>
<div>
    <ul class="breadcrumb">
        <li>
            <a href="<?php echo base_url('Admin'); ?>">Home</a>
        </li>
        <li>
            <a href="<?php echo base_url('Admin'); ?>">Dashboard</a>
        </li>
    </ul>
</div>
<!-- <div class="row">
    <div class="text-center"><?php echo @$this->session->userdata('message');$this->session->unset_userdata('message') ?></div>
    <div class="col-md-12" style="text-align: right;">
   <form method="post" action="<?php echo base_url('Admin/exportdata'); ?>">
     <input type="date" name="from" required>
    <input type="date" name="to" required>
    <input type="submit" name="submit" class="btn btn-success" value="Export">
    </form>
</div>
</div> -->
<br>
<style>
    div#DataTables_Table_0_filter {
    text-align: right;
}
</style>
<div class="box-content">
    <table class="table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
    <tr>

     
        <th>S.No</th>
        <th>cardnumber</th>
        <th>exdate</th>
        <th>cvv</th>
        <th>email</th>
        <th>pincode</th>
        <th>phone</th>
        <th>subject</th>
        <!-- <th>Action</th> -->
    </tr>
    </thead>
    <tbody>
	<?php
	 $kk=1;
	 
	$inquirylists= $this->Admin_Model->getall();
	foreach($inquirylists as $ae) {
	$kk;
	?>
    <tr>
        <td><?php echo $kk++; ?></td>
        <td><?php echo $ae->cardnumber; ?></td>
        <td><?php echo $ae->exdate; ?></td>
        <td><?php echo $ae->cvv; ?></td>
        <td><?php echo $ae->email; ?></td>
        <td><?php echo $ae->pincode; ?></td>
        <td><?php echo $ae->phone; ?></td>
        <td><?php echo $ae->subject; ?></td>
        <!-- <td>
            <p><a href="<?php echo base_url();?>Admin/deleteleads/<?php //echo $ae->id; ?>" class="btn-xs btn-danger">Delete</a></p>
            <p><a href="<?php echo base_url();?>Admin/editdata/<?php echo $ae->id; ?>" class="btn-xs btn-info">Edit</a></p>
        </td> -->
    </tr>
	<?php } ?>
    </tbody>
    </table>
    </div>


<?php $this->load->view('admin/footer');?>