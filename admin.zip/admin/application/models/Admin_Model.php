<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_Model extends CI_Model {


  function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

	public function getAllunapprovedRegistered()
	{
		$this->db->select('*');
		$this->db->where('registration_status',0);
		$getResult = $this->db->get('exp_instructor');
        return $getResult->result(); 
	}
	public function getAllapprovedRegistered()
	{
		$this->db->select('*');
		$this->db->where('registration_status',1);
		$getResult = $this->db->get('exp_instructor');
        return $getResult->result(); 
	}
	public function getInstructorDetails($id)
	{
		$this->db->select('*');
		$this->db->where('ins_id',$id);
		$getResult = $this->db->get('exp_instructor');
        return $getResult->row();
	}
	

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
 	public function getAdminLogin()
	{
		$this->db->select('*');
		$this->db->where('admin_name',$this->input->post('adminUsername'));
		$query = $this->db->get('admin_login');
        return $query->row();
	}
	
	
	public function getinquirylists()
	{
	    $this->db->select('*');
	    $this->db->order_by('id','desc');
	    $this->db->where('from','Facebook');
		$query = $this->db->get('dev_query');
        return $query->result();
	}
	public function checkduplicatenumber($phone)
	{
	    $this->db->select('*');
	    $this->db->where('phone',$phone);
		$query = $this->db->get('dev_query');
        return $query->result();
	}
	public function editLead()
	{
	    $this->db->set('service',$this->input->post('services'));
	    $this->db->set('name',$this->input->post('name'));
	    $this->db->set('phone',$this->input->post('phone'));
	    $this->db->set('email',$this->input->post('email'));
	    $this->db->set('state',$this->input->post('state'));
	    $this->db->set('city',$this->input->post('city'));
	    $this->db->set('message',$this->input->post('messages'));
	    $this->db->set('remark',$this->input->post('remark'));
	    $this->db->set('source',$this->input->post('source'));
	    $this->db->where('id',$this->input->post('id'));
	    $this->db->update('dev_query');
	    
	}

	public function getall()
	{
	    $this->db->select('*');
		  $query = $this->db->get('dev_query');
      return $query->result();
	}


}



