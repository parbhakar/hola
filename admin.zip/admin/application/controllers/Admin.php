<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	 
	public function __Construct()
	{
		parent::__construct();
		$this->load->model('Admin_Model'); 
		
		$this->load->helper('url');
		$this->load->helper('mailer_helper');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="font-size:13px;font-style: italic;margin-top:-10px;margin-bottom:10px;">', '</div>');
	}
	 public function checkSession()
	{
		$session_id=$this->session->userdata('adminLogged_in'); 	
 	    if (empty($session_id)) { 		
 	        redirect(base_url('Admin/login.html'));
		}
	}
	public function index()
	{
		
		$session_id = $this->session->userdata('adminLogged_in');
		 
		if($session_id!="")
		{
		 	$this->load->view('admin/index');
		}
		else
		{
			$this->load->view('admin/login');
		}
		
	}
	
	public function adminloginForm()
	{
		  
		$this->load->library('form_validation');
		$this->form_validation->set_rules('adminUsername','Username','trim|required|xss_clean');
		$this->form_validation->set_rules('adminPassword','Password','trim|required|xss_clean');
	 
				
				
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('admin/login');			
		}
		else
		{
			// $currentUserDetail = array("adminPassword"=>"e6e061838856bf47e1de730719fb2609","adminUsername"=>"admin");
			$currentUserDetail = $this->Admin_Model->getAdminLogin();	

			//print_r($currentUserDetail); die();
			if($currentUserDetail)
			{
			 	$getDbPaas = $currentUserDetail->admin_password;
				$getUserPaas = md5($this->input->post('adminPassword'));	
			
					if($getUserPaas==$getDbPaas)
					{
						 
						$newdata = array(
							'activeAdminUser'  => $currentUserDetail->admin_name,
							'adminLogged_in' => TRUE
						);
						
					 	$this->session->set_userdata($newdata);
						header("Location:".base_url('admin/dashboard.html'));
					}
					else
					{
						 
						$data['error_message'] = "Password is not Valid.";
					}
			}	
			else
			{
				$data['error_message'] = "Username does Not Exists.";
				
			}
			
			$this->load->view('admin/login',$data);
			
		}

	}
	public function adminLogout()
	{

		$removeData = array(
                   'activeAdminUser'  => "",
                   'adminLogged_in' => 0
               );
		//$this->session->unset_userdata($removeData);
		$this->session->sess_destroy($removeData);
		header("Location:".base_url('Admin'));
	}
	
	public function dashboard()
	{
		$this->load->view('admin/index');
	}
	
	
	public function object_to_array($data)
	{
		if (is_array($data) || is_object($data))
		{
			$result = array();
			foreach ($data as $key => $value)
			{
				$result[$key] = $this->object_to_array($value);
			}
			return $result;
		}
		return $data;
	}
	public function export($data)
	{
	     $file_name = 'thehealingtoucheyecentre_'.rand(999,99999).date('Ymd').'.csv'; 
		 header("Content-Description: File Transfer"); 
		 header("Content-Disposition: attachment; filename=$file_name"); 
		 header("Content-Type: application/csv;");
	    
		 $data = $this->object_to_array($data);
		 // file creation 
		 $file = fopen('php://output', 'w');
	 
		 $header = array_keys($data[0]); //array("Student Name","Student Phone"); 
		  
		 
		 fputcsv($file, $header);
		 foreach ($data as $key => $value)
		 { 
		   fputcsv($file, $value); 
		 }
		 fclose($file); 
		 exit; 
	}
	
	public function exportdata()
	{
	    
	    $this->db->select('*');
	    
	    $fromdate=$this->input->post('from');
	    $todate=$this->input->post('to');
	    if($fromdate!="" && $todate!="")
		{
		  $this->db->where('created >=', $fromdate);
		  $this->db->where('created <=', $todate);
		}
	    $this->db->where('from','Facebook');
	    $exportData=$this->db->get('dev_query')->result();
	    $this->export($exportData);
	    redirect(base_url('admin/dashboard.html'));
	}
	
    public function deleteleads($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('dev_query');
        $sessionData = array('message'  => '<span class="text-success">Lead Delete Successfully !!</span>');
		$this->session->set_userdata($sessionData);
        redirect(base_url('admin/dashboard.html'));
    }
    
    public function editdata($id){
        $this->db->where('id',$id);
        $data['leads']=$this->db->get('dev_query')->row();
        $this->load->view('admin/edit',$data);
    }

    public function submiteditform()
	{
	
		$this->load->library('form_validation');
		$this->form_validation->set_rules('id', 'id', 'trim|required|xss_clean');
		$this->form_validation->set_rules('services', 'services', 'trim|xss_clean');
		$this->form_validation->set_rules('name', 'name', 'trim|xss_clean');
        $this->form_validation->set_rules('phone', 'phone', 'trim|xss_clean');
        $this->form_validation->set_rules('email', 'email', 'trim|xss_clean');
        $this->form_validation->set_rules('state', 'state', 'trim|xss_clean');
        $this->form_validation->set_rules('city', 'city', 'trim|xss_clean');
        $this->form_validation->set_rules('source', 'source', 'trim|xss_clean');
        $this->form_validation->set_rules('messages', 'messages', 'trim|xss_clean');
        $this->form_validation->set_rules('remark', 'remark', 'trim|xss_clean');

		if ($this->form_validation->run() == FALSE)
		{
		    $this->db->where('id',$this->input->post('id'));
            $data['leads']=$this->db->get('dev_query')->row();
			$this->load->view('admin/edit',$data);			
		}
		else
		{
		 	$this->Admin_Model->editLead();
			$sessionData = array('message'  => '<span class="text-success">Lead Update Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			header("Location:".base_url()."admin/dashboard.html");
		}

	}
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */