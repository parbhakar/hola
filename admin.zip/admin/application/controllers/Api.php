<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Api extends CI_Controller {

	public function __Construct()
	{
			parent::__construct();
			header('Access-Control-Allow-Origin: *');
			
			header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept,Authorization ");
		
	}
	
	public function index()
	{
		
	}
	public function insertlead()
	{
		//{"form_name":"Enquery.in Skycity","subject":"Enquery Skycity Quick Contact","name":"Kumar","email":"info@Enquery.com","phone":"8855447744","message":"Hello Star"}
		$mailRequest=file_get_contents("php://input");
      //  file_put_contents('mail_request.txt', $mailRequest);
        if (!empty($mailRequest))
        {
            $mailRequestArray=json_decode($mailRequest,  true);
            //print_r($mailRequestArray); die();
            $form_name = $mailRequestArray['form_name'];
            $subject = $mailRequestArray['subject'];
            $name = $mailRequestArray['name'];
            $email = $mailRequestArray['email'];
            $phone = $mailRequestArray['phone'];
            $message = $mailRequestArray['message'];
            
            $this->db->set('form_name',$form_name);
            $this->db->set('subject',$subject);
            $this->db->set('name',$name);
            $this->db->set('email',$email);
            $this->db->set('phone',$phone);
            $this->db->set('message',$message);
            $this->db->set('status',1);
            if(!empty($mailRequestArray['from'])){
                $this->db->set('from',$mailRequestArray['from']);
            }else{
                 $this->db->set('from','Google');
            }
            $this->db->insert('dev_query');
            
            $response = array("status_code" =>200 ,  "status" => "success", "message" => "Lead Insert Successfully, Thanks You.","data" => "" );
			echo  json_encode($response);
        }else{
            $response = array("status_code" =>201 ,  "status" => "failed", "message" => "Please Enter All Fild.","data" => "" );
			echo  json_encode($response);
        }
	}
}
