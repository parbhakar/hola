<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if ( ! function_exists('mailerHtml'))
{
function mailerHtml($message)
{		 $message = '<html>
   <body>
      <table style="border:10px solid #FFDD00" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="650">
         <tbody>
            <tr>
               <td align="left" valign="top">
                  <table style="border-bottom:1px solid #cccccc;background:#ffffff;" border="0" cellpadding="0" cellspacing="0" width="650">
                     <tbody>
                        <tr>
                           <td style="padding:5px" align="left" valign="middle" width="275"><img class="CToWUd" alt="theluxecarwash.com" src="https://www.theluxecarwash.com/assets/img/logo.png"  width="120"></td>
                           <td style="font-family:Arial;font-size:14px;color:#555555;padding:30px" align="right" valign="middle" width="255">&nbsp;</td>
                        </tr>
                     </tbody>
                  </table>
               </td>
            </tr>
            <tr>
               <td align="left" valign="top">
                  <table border="0" cellpadding="0" cellspacing="0" width="650">
                     <tbody>
                        <tr>
                           <td colspan="3" height="30" width="100%">&nbsp;</td>
                        </tr>
                        <tr>
                           <td width="30">&nbsp;</td>
                           <td style="font-size:13px;color:#333333" width="590">
                              <p style="font-family:Arial;color:#ffffff;margin-bottom:0.5em;margin-top:0">'.$message.'</p>
                              <div><b> Thank you !</b> </div>
                              <div><b> <span class="il">Team theluxecarwash</span></b>  </div>
                           </td>
                           <td width="30">&nbsp;</td>
                        </tr>
                        <tr>
                           <td colspan="3" height="30" width="100%">&nbsp;</td>
                        </tr>
                     </tbody>
                  </table>
               </td>
            </tr>
         </tbody>
      </table>
   </body>
</html>'; return $message;
}
}